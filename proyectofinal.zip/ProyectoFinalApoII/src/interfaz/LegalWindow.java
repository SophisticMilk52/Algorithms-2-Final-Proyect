package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JDialog;

/**
 * Esta clase pretende ofrecer la ventana visible que contendrá el diseño que ofrecerá el "PanelLegal", donde el usuario podrá visualizar y aceptar, o no, los terminos del software 
 */
public class LegalWindow extends JDialog{
	
	/**
	 * Relaciones entre clases
	 */
	public PanelLegal pLegal;//Relación con la clase PanelLegal

	public LegalWindow(Principal p) {
		super(p);
		
		pLegal=new PanelLegal(p);
		setTitle("Match Icesi");
		setSize(500,600);
		setVisible(true);
		setLayout(new GridLayout());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		
		add(pLegal,BorderLayout.CENTER);
	}

}
